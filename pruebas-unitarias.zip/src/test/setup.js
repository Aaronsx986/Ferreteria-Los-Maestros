import '@testing-library/jest-dom/vitest'
import { afterEach } from 'vitest'
import { cleanup } from '@testing-library/react'

// Cada prueba parte de cero: sin DOM anterior y sin datos en localStorage
afterEach(() => {
  cleanup()
  localStorage.clear()
})
