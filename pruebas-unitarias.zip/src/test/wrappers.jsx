import { MemoryRouter } from 'react-router-dom'
import { AuthProvider } from '../context/AuthContext.jsx'
import { ShopProvider } from '../context/ShopContext.jsx'
import { CartProvider } from '../context/CartContext.jsx'

// Mismo orden que en main.jsx (Cart necesita Shop)
export function AllProviders({ children, route = '/' }) {
  return (
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <ShopProvider>
          <CartProvider>{children}</CartProvider>
        </ShopProvider>
      </AuthProvider>
    </MemoryRouter>
  )
}

export const withProviders = (route) => ({ children }) => (
  <AllProviders route={route}>{children}</AllProviders>
)
