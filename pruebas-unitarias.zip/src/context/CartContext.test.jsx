import { describe, it, expect } from 'vitest'
import { renderHook, act } from '@testing-library/react'
import { useCart } from './CartContext.jsx'
import { withProviders } from '../test/wrappers.jsx'

// Producto 1: Cemento Polpaico, $5.990, stock 80
const wrapper = withProviders()

describe('CartContext', () => {
  it('parte vacío', () => {
    const { result } = renderHook(() => useCart(), { wrapper })
    expect(result.current.items).toEqual([])
    expect(result.current.count).toBe(0)
    expect(result.current.total).toBe(0)
  })

  it('agrega un producto y calcula count y total', () => {
    const { result } = renderHook(() => useCart(), { wrapper })
    act(() => { result.current.addToCart(1, 2) })
    expect(result.current.count).toBe(2)
    expect(result.current.total).toBe(5990 * 2)
    expect(result.current.items[0].name).toMatch(/Cemento/)
  })

  it('agregar el mismo producto suma la cantidad', () => {
    const { result } = renderHook(() => useCart(), { wrapper })
    act(() => { result.current.addToCart(1) })
    act(() => { result.current.addToCart(1) })
    expect(result.current.items).toHaveLength(1)
    expect(result.current.qtyInCart(1)).toBe(2)
  })

  it('nunca supera el stock disponible', () => {
    localStorage.setItem('flm_stock', JSON.stringify({ 1: 3 }))
    const { result } = renderHook(() => useCart(), { wrapper })
    act(() => { result.current.addToCart(1, 10) })
    expect(result.current.qtyInCart(1)).toBe(3)
    let added
    act(() => { added = result.current.addToCart(1) })
    expect(added).toBe(false)
  })

  it('no agrega productos sin stock', () => {
    localStorage.setItem('flm_stock', JSON.stringify({ 1: 0 }))
    const { result } = renderHook(() => useCart(), { wrapper })
    let added
    act(() => { added = result.current.addToCart(1) })
    expect(added).toBe(false)
    expect(result.current.count).toBe(0)
  })

  it('updateQty cambia la cantidad y 0 elimina la línea', () => {
    const { result } = renderHook(() => useCart(), { wrapper })
    act(() => { result.current.addToCart(1, 2) })
    act(() => { result.current.updateQty(1, 5) })
    expect(result.current.qtyInCart(1)).toBe(5)
    act(() => { result.current.updateQty(1, 0) })
    expect(result.current.items).toHaveLength(0)
  })

  it('updateQty respeta el stock máximo', () => {
    localStorage.setItem('flm_stock', JSON.stringify({ 1: 4 }))
    const { result } = renderHook(() => useCart(), { wrapper })
    act(() => { result.current.addToCart(1) })
    act(() => { result.current.updateQty(1, 99) })
    expect(result.current.qtyInCart(1)).toBe(4)
  })

  it('removeFromCart y clearCart vacían lo esperado', () => {
    const { result } = renderHook(() => useCart(), { wrapper })
    act(() => { result.current.addToCart(1); result.current.addToCart(2) })
    act(() => { result.current.removeFromCart(1) })
    expect(result.current.items.map((i) => i.id)).toEqual([2])
    act(() => { result.current.clearCart() })
    expect(result.current.items).toEqual([])
  })

  it('el carrito se guarda en localStorage como {id, qty}', () => {
    const { result } = renderHook(() => useCart(), { wrapper })
    act(() => { result.current.addToCart(1, 2) })
    expect(JSON.parse(localStorage.getItem('flm_cart'))).toEqual([{ id: 1, qty: 2 }])
  })
})
