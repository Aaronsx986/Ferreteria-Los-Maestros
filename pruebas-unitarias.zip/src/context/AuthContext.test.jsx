import { describe, it, expect } from 'vitest'
import { renderHook, act } from '@testing-library/react'
import { AuthProvider, useAuth } from './AuthContext.jsx'

const wrapper = ({ children }) => <AuthProvider>{children}</AuthProvider>
const form = {
  name: 'Ana Pérez', username: 'ana', email: 'ana@test.cl',
  phone: '+56 9 1111 1111', address: 'Calle 1', password: 'secreto1',
}

describe('AuthContext', () => {
  it('login correcto de admin guarda sesión sin contraseña', () => {
    const { result } = renderHook(() => useAuth(), { wrapper })
    let res
    act(() => { res = result.current.login('admin', 'admin123') })
    expect(res.ok).toBe(true)
    expect(result.current.isAdmin).toBe(true)
    expect(result.current.user.password).toBeUndefined()
    expect(JSON.parse(localStorage.getItem('currentUser')).username).toBe('admin')
  })

  it('el usuario normal no es admin', () => {
    const { result } = renderHook(() => useAuth(), { wrapper })
    act(() => { result.current.login('usuario', 'user123') })
    expect(result.current.isAdmin).toBe(false)
  })

  it('login ignora mayúsculas y espacios en el usuario', () => {
    const { result } = renderHook(() => useAuth(), { wrapper })
    let res
    act(() => { res = result.current.login('  ADMIN ', 'admin123') })
    expect(res.ok).toBe(true)
  })

  it('contraseña incorrecta falla y no crea sesión', () => {
    const { result } = renderHook(() => useAuth(), { wrapper })
    let res
    act(() => { res = result.current.login('admin', 'mala') })
    expect(res).toEqual({ ok: false, message: 'Usuario o contraseña incorrectos' })
    expect(result.current.user).toBeNull()
  })

  it('cuenta inactiva no puede entrar', () => {
    localStorage.setItem('flm_users', JSON.stringify([{ ...form, role: 'user', status: 'inactive' }]))
    const { result } = renderHook(() => useAuth(), { wrapper })
    let res
    act(() => { res = result.current.login('ana', 'secreto1') })
    expect(res.ok).toBe(false)
    expect(res.message).toMatch(/inactiva/)
  })

  it('register crea siempre un cliente y permite iniciar sesión', () => {
    const { result } = renderHook(() => useAuth(), { wrapper })
    let res
    act(() => { res = result.current.register(form) })
    expect(res.ok).toBe(true)
    const nuevo = result.current.users.find((u) => u.username === 'ana')
    expect(nuevo.role).toBe('user')
    act(() => { result.current.login('ana', 'secreto1') })
    expect(result.current.user.username).toBe('ana')
  })

  it('register rechaza usuario repetido', () => {
    const { result } = renderHook(() => useAuth(), { wrapper })
    let res
    act(() => { res = result.current.register({ ...form, username: 'Admin' }) })
    expect(res.ok).toBe(false)
    expect(res.message).toMatch(/usuario/)
  })

  it('register rechaza correo repetido', () => {
    const { result } = renderHook(() => useAuth(), { wrapper })
    let res
    act(() => { res = result.current.register({ ...form, email: 'ADMIN@ferreterialosmaestros.cl' }) })
    expect(res.ok).toBe(false)
    expect(res.message).toMatch(/correo/)
  })

  it('logout limpia la sesión', () => {
    const { result } = renderHook(() => useAuth(), { wrapper })
    act(() => { result.current.login('admin', 'admin123') })
    act(() => { result.current.logout() })
    expect(result.current.user).toBeNull()
    expect(localStorage.getItem('currentUser')).toBeNull()
  })

  it('recupera la sesión guardada al recargar', () => {
    localStorage.setItem('currentUser', JSON.stringify({ username: 'usuario', role: 'user' }))
    const { result } = renderHook(() => useAuth(), { wrapper })
    expect(result.current.user.username).toBe('usuario')
  })
})
