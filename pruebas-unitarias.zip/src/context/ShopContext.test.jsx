import { describe, it, expect } from 'vitest'
import { renderHook, act } from '@testing-library/react'
import { useShop } from './ShopContext.jsx'
import { MemoryRouter } from 'react-router-dom'
import { ShopProvider } from './ShopContext.jsx'

const wrapper = ({ children }) => (
  <MemoryRouter>
    <ShopProvider>{children}</ShopProvider>
  </MemoryRouter>
)

const user = { username: 'usuario', name: 'Cliente Ejemplo' }
const item = (id, qty, price = 5990) => ({ id, code: 'X', name: `Prod ${id}`, price, qty, imagen: '' })

describe('ShopContext.placeOrder', () => {
  it('rechaza si no hay sesión', () => {
    const { result } = renderHook(() => useShop(), { wrapper })
    let res
    act(() => { res = result.current.placeOrder({ user: null, items: [item(1, 1)], payment: 'debito', delivery: 'retiro' }) })
    expect(res.ok).toBe(false)
    expect(res.message).toMatch(/iniciar sesión/)
  })

  it('rechaza un carrito vacío', () => {
    const { result } = renderHook(() => useShop(), { wrapper })
    let res
    act(() => { res = result.current.placeOrder({ user, items: [], payment: 'debito', delivery: 'retiro' }) })
    expect(res.ok).toBe(false)
    expect(res.message).toMatch(/vacío/)
  })

  it('rechaza si no hay stock suficiente y no cambia nada', () => {
    const { result } = renderHook(() => useShop(), { wrapper })
    let res
    act(() => { res = result.current.placeOrder({ user, items: [item(1, 9999)], payment: 'debito', delivery: 'retiro' }) })
    expect(res.ok).toBe(false)
    expect(res.message).toMatch(/stock/)
    expect(result.current.orders).toHaveLength(0)
  })

  it('crea la orden con ID C-1001, total correcto y estado de retiro', () => {
    const { result } = renderHook(() => useShop(), { wrapper })
    let res
    act(() => { res = result.current.placeOrder({ user, items: [item(1, 2), item(2, 1, 7490)], payment: 'debito', delivery: 'retiro' }) })
    expect(res.ok).toBe(true)
    expect(res.order.id).toBe('C-1001')
    expect(res.order.total).toBe(5990 * 2 + 7490)
    expect(res.order.estado).toBe('Listo para retiro')
    expect(res.order.username).toBe('usuario')
  })

  it('con despacho el estado es En preparación', () => {
    const { result } = renderHook(() => useShop(), { wrapper })
    let res
    act(() => { res = result.current.placeOrder({ user, items: [item(1, 1)], payment: 'credito', delivery: 'despacho' }) })
    expect(res.order.estado).toBe('En preparación')
  })

  it('descuenta el stock del catálogo', () => {
    const { result } = renderHook(() => useShop(), { wrapper })
    const antes = result.current.products.find((p) => p.id === 1).stock
    act(() => { result.current.placeOrder({ user, items: [item(1, 5)], payment: 'debito', delivery: 'retiro' }) })
    expect(result.current.products.find((p) => p.id === 1).stock).toBe(antes - 5)
    expect(JSON.parse(localStorage.getItem('flm_stock'))[1]).toBe(antes - 5)
  })

  it('los IDs de compra son correlativos', () => {
    const { result } = renderHook(() => useShop(), { wrapper })
    act(() => { result.current.placeOrder({ user, items: [item(1, 1)], payment: 'debito', delivery: 'retiro' }) })
    let res
    act(() => { res = result.current.placeOrder({ user, items: [item(1, 1)], payment: 'debito', delivery: 'retiro' }) })
    expect(res.order.id).toBe('C-1002')
  })

  it('la compra más nueva queda primera en la lista', () => {
    const { result } = renderHook(() => useShop(), { wrapper })
    act(() => { result.current.placeOrder({ user, items: [item(1, 1)], payment: 'debito', delivery: 'retiro' }) })
    act(() => { result.current.placeOrder({ user, items: [item(2, 1)], payment: 'debito', delivery: 'retiro' }) })
    expect(result.current.orders[0].id).toBe('C-1002')
  })
})

describe('ShopContext.addRental / addService', () => {
  it('addRental crea A-201 en estado Solicitado', () => {
    const { result } = renderHook(() => useShop(), { wrapper })
    let r
    act(() => {
      r = result.current.addRental({
        user, tool: { id: 20, name: 'Martillo' }, inicio: '2026-11-01', termino: '2026-11-03',
        dias: 3, pago: 'efectivo', deposito: 15980, costo: 23970, comentarios: '',
      })
    })
    expect(r.id).toBe('A-201')
    expect(r.estado).toBe('Solicitado')
    expect(result.current.rentals).toHaveLength(1)
    expect(JSON.parse(localStorage.getItem('flm_rentals'))).toHaveLength(1)
  })

  it('addService crea S-301 con la marca en el nombre', () => {
    const { result } = renderHook(() => useShop(), { wrapper })
    let s
    act(() => {
      s = result.current.addService({
        user, tipo: 'Taladro', marca: 'Makita', urgencia: 'alta',
        fecha: '2026-11-02', hora: '10:00', descripcion: 'No enciende',
      })
    })
    expect(s.id).toBe('S-301')
    expect(s.servicio).toBe('Reparación Taladro (Makita)')
    expect(s.agendado).toBe('2026-11-02 10:00')
    expect(s.completado).toBeNull()
  })
})
