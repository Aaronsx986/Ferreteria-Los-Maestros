import { describe, it, expect, vi } from 'vitest'
import { norm, clp, formatDate, load, save } from './utils.js'

describe('norm', () => {
  it('pasa a minúsculas y quita tildes', () => {
    expect(norm('Cerámica ÁÉÍÓÚ')).toBe('ceramica aeiou')
  })
  it('tolera undefined y números', () => {
    expect(norm()).toBe('')
    expect(norm(123)).toBe('123')
  })
})

describe('clp', () => {
  it('formatea con signo $ y separador de miles', () => {
    expect(clp(5990)).toMatch(/^\$5\.?990$/)
  })
  it('valores vacíos se muestran como $0', () => {
    expect(clp(null)).toBe('$0')
    expect(clp(undefined)).toBe('$0')
  })
})

describe('formatDate', () => {
  it('devuelve — si no hay fecha', () => {
    expect(formatDate(null)).toBe('—')
  })
  it('devuelve el texto original si la fecha es inválida', () => {
    expect(formatDate('no-es-fecha')).toBe('no-es-fecha')
  })
  it('formatea una fecha válida con el año', () => {
    expect(formatDate('2026-03-15T12:00:00Z')).toContain('2026')
  })
})

describe('load / save', () => {
  it('guarda y recupera un objeto', () => {
    save('k', { a: 1 })
    expect(load('k', null)).toEqual({ a: 1 })
  })
  it('devuelve el fallback si la clave no existe', () => {
    expect(load('no-existe', [])).toEqual([])
  })
  it('devuelve el fallback si el JSON está corrupto', () => {
    localStorage.setItem('roto', '{no es json')
    expect(load('roto', 'fallback')).toBe('fallback')
  })
  it('save no lanza error si localStorage falla', () => {
    const spy = vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
      throw new Error('lleno')
    })
    expect(() => save('k', 1)).not.toThrow()
    spy.mockRestore()
  })
})
