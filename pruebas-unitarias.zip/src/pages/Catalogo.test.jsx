import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import Catalogo from './Catalogo.jsx'
import { AllProviders } from '../test/wrappers.jsx'

const renderAt = (route) =>
  render(<AllProviders route={route}><Catalogo /></AllProviders>)

// Cuenta cuántas tarjetas hay mirando el texto "N productos encontrados"
const cuenta = () => {
  const txt = screen.getByText(/producto(s)? encontrado/).textContent
  return parseInt(txt, 10)
}

describe('Catalogo (filtros por URL)', () => {
  it('sin filtros muestra los 85 productos', () => {
    renderAt('/catalogo')
    expect(cuenta()).toBe(85)
  })

  it('filtra por categoría', () => {
    renderAt('/catalogo?cat=herramientas')
    expect(cuenta()).toBeGreaterThan(0)
    expect(cuenta()).toBeLessThan(85)
    expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent(/Herramientas|herramientas/i)
  })

  it('la búsqueda ignora tildes y mayúsculas', () => {
    renderAt('/catalogo?q=MELON')
    expect(screen.getByText('Cemento Melón blanco 25 kg')).toBeInTheDocument()
  })

  it('la búsqueda exige todas las palabras', () => {
    renderAt('/catalogo?q=cemento polpaico')
    expect(screen.getByText('Cemento Polpaico gris 25 kg')).toBeInTheDocument()
    expect(screen.queryByText('Cemento Melón blanco 25 kg')).not.toBeInTheDocument()
  })

  it('filtra por rango de precio', () => {
    renderAt('/catalogo?min=100000')
    const sinResultados = screen.queryByText(/No se encontraron productos/)
    if (!sinResultados) expect(cuenta()).toBeLessThan(85)
  })

  it('ordena por precio de menor a mayor', () => {
    renderAt('/catalogo?sort=precio-asc&max=3000')
    const precios = screen.getAllByText(/^\$\d/).map((el) => Number(el.textContent.replace(/\D/g, '')))
    const ordenados = [...precios].sort((a, b) => a - b)
    expect(precios).toEqual(ordenados)
  })

  it('sin coincidencias muestra el mensaje vacío', () => {
    renderAt('/catalogo?q=zzzzzzzz')
    expect(screen.getByText(/No se encontraron productos/)).toBeInTheDocument()
  })

  it('solo con stock oculta los agotados', () => {
    localStorage.setItem('flm_stock', JSON.stringify({ 1: 0 }))
    renderAt('/catalogo?stock=1')
    expect(cuenta()).toBe(84)
  })
})
