import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Routes, Route } from 'react-router-dom'
import { AuthProvider } from '../context/AuthContext.jsx'
import Login from './Login.jsx'

function setup() {
  return render(
    <MemoryRouter initialEntries={['/login']}>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<p>Página de inicio</p>} />
        </Routes>
      </AuthProvider>
    </MemoryRouter>
  )
}

describe('Login (pantalla)', () => {
  it('credenciales correctas llevan al inicio', async () => {
    const user = userEvent.setup()
    setup()
    await user.type(screen.getByPlaceholderText('admin o usuario'), 'admin')
    await user.type(screen.getByPlaceholderText('••••••••'), 'admin123')
    await user.click(screen.getByRole('button', { name: 'Ingresar' }))
    expect(await screen.findByText('Página de inicio')).toBeInTheDocument()
  })

  it('credenciales malas muestran el error y no navegan', async () => {
    const user = userEvent.setup()
    setup()
    await user.type(screen.getByPlaceholderText('admin o usuario'), 'admin')
    await user.type(screen.getByPlaceholderText('••••••••'), 'incorrecta')
    await user.click(screen.getByRole('button', { name: 'Ingresar' }))
    expect(await screen.findByText('Usuario o contraseña incorrectos')).toBeInTheDocument()
    expect(screen.queryByText('Página de inicio')).not.toBeInTheDocument()
  })
})
