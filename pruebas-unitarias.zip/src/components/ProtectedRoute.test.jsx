import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { MemoryRouter, Routes, Route } from 'react-router-dom'
import { AuthProvider } from '../context/AuthContext.jsx'
import ProtectedRoute from './ProtectedRoute.jsx'

function setup(path, adminOnly = false) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <AuthProvider>
        <Routes>
          <Route path="/" element={<p>Inicio</p>} />
          <Route path="/login" element={<p>Pantalla login</p>} />
          <Route path="/secreto" element={<ProtectedRoute adminOnly={adminOnly}><p>Contenido protegido</p></ProtectedRoute>} />
        </Routes>
      </AuthProvider>
    </MemoryRouter>
  )
}

const sesion = (role) =>
  localStorage.setItem('currentUser', JSON.stringify({ username: 'x', role }))

describe('ProtectedRoute', () => {
  it('sin sesión redirige a /login', () => {
    setup('/secreto')
    expect(screen.getByText('Pantalla login')).toBeInTheDocument()
  })

  it('con sesión muestra el contenido', () => {
    sesion('user')
    setup('/secreto')
    expect(screen.getByText('Contenido protegido')).toBeInTheDocument()
  })

  it('ruta admin con cliente redirige al inicio', () => {
    sesion('user')
    setup('/secreto', true)
    expect(screen.getByText('Inicio')).toBeInTheDocument()
  })

  it('ruta admin con admin muestra el contenido', () => {
    sesion('admin')
    setup('/secreto', true)
    expect(screen.getByText('Contenido protegido')).toBeInTheDocument()
  })
})
