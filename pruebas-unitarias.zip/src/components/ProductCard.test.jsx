import { describe, it, expect } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import ProductCard from './ProductCard.jsx'
import { AllProviders } from '../test/wrappers.jsx'

const base = {
  id: 1, name: 'Cemento Polpaico gris 25 kg', brand: 'Polpaico', unit: 'Saco',
  price: 5990, stock: 80, imagen: '/img/x.jpg', icon: 'bi-bricks',
}

const renderCard = (product) =>
  render(<AllProviders><ProductCard product={product} /></AllProviders>)

describe('ProductCard', () => {
  it('muestra nombre, marca, precio y disponibilidad', () => {
    renderCard(base)
    expect(screen.getByText(base.name)).toBeInTheDocument()
    expect(screen.getByText('Polpaico')).toBeInTheDocument()
    expect(screen.getByText(/5\.?990/)).toBeInTheDocument()
    expect(screen.getByText('Disponible')).toBeInTheDocument()
  })

  it('con 3 unidades o menos avisa que quedan pocas', () => {
    renderCard({ ...base, stock: 3 })
    expect(screen.getByText(/Últimas unidades/)).toBeInTheDocument()
  })

  it('sin stock deshabilita el botón', () => {
    renderCard({ ...base, stock: 0 })
    expect(screen.getByText('No disponible')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /Sin stock/ })).toBeDisabled()
  })

  it('al hacer clic cambia a ¡Agregado! y guarda en el carrito', async () => {
    const user = userEvent.setup()
    renderCard(base)
    await user.click(screen.getByRole('button', { name: /Agregar al carrito/ }))
    expect(screen.getByRole('button', { name: /¡Agregado!/ })).toBeInTheDocument()
    expect(JSON.parse(localStorage.getItem('flm_cart'))).toEqual([{ id: 1, qty: 1 }])
  })

  it('al llegar al stock máximo muestra Máximo en carrito', async () => {
    localStorage.setItem('flm_stock', JSON.stringify({ 1: 1 }))
    const user = userEvent.setup()
    renderCard({ ...base, stock: 1 })
    await user.click(screen.getByRole('button', { name: /Agregar al carrito/ }))
    // Primero se ve ¡Agregado! (1,2 s) y después queda Máximo en carrito
    expect(screen.getByRole('button', { name: /¡Agregado!/ })).toBeDisabled()
    expect(
      await screen.findByRole('button', { name: /Máximo en carrito/ }, { timeout: 2500 })
    ).toBeDisabled()
  })

  it('si la imagen falla muestra el icono de respaldo', () => {
    const { container } = renderCard(base)
    fireEvent.error(container.querySelector('img'))
    expect(container.querySelector('img')).toBeNull()
    expect(container.querySelector('.bi-bricks')).toBeInTheDocument()
  })
})
